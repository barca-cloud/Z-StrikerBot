import os

os.system("python3 lichess-bot.py -u")
